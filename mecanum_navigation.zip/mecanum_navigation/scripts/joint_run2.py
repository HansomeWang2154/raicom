#!/usr/bin/env python
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Point, Quaternion, Twist
from actionlib_msgs.msg import GoalStatus
from std_msgs.msg import Int32
from tf.transformations import quaternion_from_euler
import threading

class MultiGoalPublisher:
    def __init__(self):
        rospy.init_node('multi_goal_publisher')
        
        # 创建move_base客户端
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        
        # 创建速度发布者
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        
        # 等待move_base服务器启动
        rospy.loginfo("等待move_base服务器...")
        server_ready = self.client.wait_for_server(rospy.Duration(10.0))
        if not server_ready:
            rospy.logerr("无法连接到move_base服务器!")
            rospy.signal_shutdown("move_base服务器连接失败")
            return
        
        rospy.loginfo("成功连接move_base服务器")
        
        # 创建发布者和订阅者
        self.arrived_pub = rospy.Publisher('/wheels/arrive', Int32, queue_size=10)
        self.arrived_box_pub = rospy.Publisher('/wheels/arrive_box', Int32, queue_size=10)
        self.yolo_sub = rospy.Subscriber('/yolo/picked', Int32, self.yolo_callback)
        self.yolo_received = False
        
        # 定义目标位置（删除目标点9和10）
        self.goal_list = [
            (0.55, 0.2, 0.0),     # 目标点1
            (0.55, 0.70, 0.0),   # 目标点2
            (2.21, 0.65, 0.0),   # 目标点3
            (3.5, 0.45, 0.0),    # 目标点4
            (5.0, 0.38, 0.0),    # 目标点5
            (6.23, -0.30, 0.0),  # 目标点6
            (6.30, 1.03, 0.0),   # 目标点7
            (6.30, 3.0, 0.0),   # 目标点8
            (0.40, 3.8, 0.0),    # 目标点9（原11）
            (0.60, 3.0, 0.0),     # 目标点10（原12）
            (0.92, 2.20, 0.0),   # 目标点11（原13）
            (2.21, 2.10, 0.0),   # 目标点12（原14）
            (3.8, 2.00, 0.0),    # 目标点13（原15）
            (5.5, 1.90, 0.0),    # 目标点14（原16）
            (4.0, 2.5, 0.0),     # 目标点15（原17）
            (1.0, 2.3, 0.0),     # 目标点16（原18）
            (0.40, 3.8, 0.0)     # 目标点17（原19）
        ]
        
        # 状态管理
        self.current_goal_index = 0
        self.goal_active = False
        self.goal_completed = False
        self.state_lock = threading.Lock()
        
        # 启动目标发布流程
        self.publish_next_goal()
    
    def yolo_callback(self, msg):
        """处理YOLO检测消息"""
        if msg.data == 1:
            rospy.loginfo("收到YOLO检测消息")
            self.yolo_received = True
    
    def publish_velocity(self, linear_x,linear_y, duration):
        """发布速度指令并保持指定时间"""
        twist = Twist()
        twist.linear.x = linear_x  # x方向速度
        twist.linear.y = linear_y     # y方向速度为0
        twist.angular.z = 0.0      # 角速度为0
        
        start_time = rospy.Time.now()
        
        rospy.loginfo(f"发布速度指令: x方向 {linear_x} m/s (持续{duration}秒)")
        while (rospy.Time.now() - start_time).to_sec() < duration and not rospy.is_shutdown():
            self.cmd_vel_pub.publish(twist)
            rospy.sleep(0.1)
        
        # 停止
        twist.linear.x = 0.0
        self.cmd_vel_pub.publish(twist)
        rospy.loginfo("速度指令结束")

    def publish_next_goal(self):
        with self.state_lock:
            if self.current_goal_index >= len(self.goal_list):
                rospy.loginfo("所有目标点已完成!")
                rospy.signal_shutdown("任务完成")
                return
            
            # 确保前一个目标已完全清理
            if self.goal_active:
                rospy.logwarn("取消当前活动目标")
                self.client.cancel_goal()
                rospy.sleep(0.5)
                self.goal_active = False
            
            # 重置状态标志
            self.goal_completed = False
            self.yolo_received = False
            
            # 获取当前目标
            goal_info = self.goal_list[self.current_goal_index]
            x, y, theta = goal_info
            
            # 创建目标
            goal = MoveBaseGoal()
            goal.target_pose.header.frame_id = "map"
            goal.target_pose.header.stamp = rospy.Time.now()
            goal.target_pose.pose.position = Point(x, y, 0.0)
            quat = quaternion_from_euler(0, 0, theta)
            goal.target_pose.pose.orientation = Quaternion(*quat)
            
            # 发布目标
            rospy.loginfo(f"发布目标#{self.current_goal_index+1}: 位置({x:.1f}, {y:.1f}), 朝向: {theta:.2f} 弧度")
            
            # 检查客户端状态
            if self.client.get_state() in [GoalStatus.PENDING, GoalStatus.ACTIVE]:
                rospy.logwarn("客户端仍在处理目标，先取消")
                self.client.cancel_goal()
                rospy.sleep(0.2)
            
            self.client.send_goal(goal, done_cb=self.goal_done_cb)
            self.goal_active = True
            
            # 设置20秒超时
            if hasattr(self, 'timeout_timer'):
                self.timeout_timer.shutdown()
            self.timeout_timer = rospy.Timer(rospy.Duration(20.0), self.timeout_cb, oneshot=True)
            rospy.loginfo(f"等待20秒，如果超时将放弃目标#{self.current_goal_index+1}")
    
    def goal_done_cb(self, status, result):
        with self.state_lock:
            if self.goal_completed:
                return
            self.goal_completed = True
            
            # 取消超时计时器
            if hasattr(self, 'timeout_timer') and self.timeout_timer.is_alive():
                self.timeout_timer.shutdown()
            
            # 标记目标不再活动
            self.goal_active = False
            
            # 检查目标状态
            if status == GoalStatus.SUCCEEDED:
                rospy.loginfo(f"成功到达目标#{self.current_goal_index+1}")
            else:
                rospy.logwarn(f"无法到达目标#{self.current_goal_index+1}，状态代码: {status}")
            
            # 特殊点处理
            if self.current_goal_index == 7:  # 目标点8
                rospy.loginfo("到达目标点8，发布x方向1m/s速度持续5秒")
                self.publish_velocity(-0.5, 0.0, 3.0)
                rospy.sleep(0.5)
                self.publish_velocity(-0.4, 0.0,5.0)
                # 设置新的运动参数（旋转相关）
                rospy.loginfo("更新运动控制参数")
                rospy.set_param('/move_base/DWAPlannerROS/max_vel_theta', 1.0)      # 最大旋转速度
                rospy.set_param('/move_base/DWAPlannerROS/min_vel_theta', -1.0)     # 最小旋转速度
                rospy.set_param('/move_base/DWAPlannerROS/acc_lim_theta', 1.0)     # 旋转加速度限制
                
                # 重载参数使设置生效
                rospy.sleep(0.5)  # 等待参数设置完成
                rospy.loginfo("重载move_base参数")
                try:
                    reload_service = rospy.ServiceProxy('/move_base/reload_parameters', Empty)
                    reload_service()
                except rospy.ServiceException as e:
                    rospy.logerr(f"参数重载失败: {str(e)}")
            
            elif self.current_goal_index == 8:  # 目标点9（原11）
                rospy.loginfo("发布到达box消息")
                self.arrived_box_pub.publish(Int32(1))
                self.publish_velocity(0.0, 0.1 , 1)  # y方向0.1
                self.publish_velocity(-0.1, 0.0 , 1)  # x方向-0.1
                rospy.sleep(5.0)
            
            elif self.current_goal_index == 16:  # 目标点17（原19）
                rospy.loginfo("发布到达box消息")
                self.arrived_box_pub.publish(Int32(1))
                self.publish_velocity(0.0, 0.1 , 1)  # y方向0.1
                self.publish_velocity(-0.1, 0.0 , 1)  # x方向-0.1
                rospy.sleep(5.0)
            
            elif self.current_goal_index == 9:  # 目标点10（原12）前
                self.publish_velocity(0.1, 0.0 , 1)  # x方向-0.1
                self.publish_velocity(0.0, -0.1 , 1)  # y方向0.1
                rospy.sleep(0.5)
            
            elif self.current_goal_index in [1, 2, 3, 4, 10, 11, 12, 13]:  # 需要等待YOLO的目标点
                rospy.loginfo("发布到达消息")
                self.arrived_pub.publish(Int32(1))
                
                rospy.loginfo("等待YOLO检测消息...")
                self.yolo_received = False
                while not self.yolo_received and not rospy.is_shutdown():
                    rospy.sleep(0.1)
                rospy.loginfo("收到YOLO检测消息")
            
            elif self.current_goal_index in [6, 14, 15]:  # 需要立即发布下一个目标点的点
                rospy.loginfo("目标点#{self.current_goal_index+1}完成，立即发布下一个目标")
            
            # 准备下一个目标
            self.current_goal_index += 1
            
            # 延迟发布下一个目标
            rospy.Timer(rospy.Duration(0.5), self.delayed_publish, oneshot=True)
    
    def delayed_publish(self, event):
        """延迟发布下一个目标"""
        self.publish_next_goal()
    
    def timeout_cb(self, event):
        with self.state_lock:
            if self.goal_completed:
                return
            self.goal_completed = True
                
            if not self.goal_active:
                return
                
            rospy.logwarn(f"目标#{self.current_goal_index+1} 20秒超时，取消当前目标")
            
            # 取消当前目标
            self.client.cancel_goal()
            rospy.sleep(0.5)
            self.goal_active = False
            
            # 特殊点处理
            if self.current_goal_index == 7:  # 目标点8
                rospy.loginfo("目标8超时，发布x方向1m/s速度持续5秒")
                self.publish_velocity(-0.8,0.0, 3.0)
                self.publish_velocity(-0.5,0.0, 3.0)
            
            elif self.current_goal_index == 8:  # 目标点9（原11）
                rospy.loginfo("发布到达box消息")
                self.arrived_box_pub.publish(Int32(1))
                self.publish_velocity(0.0, 0.1 , 1)  # y方向0.1
                self.publish_velocity(-0.1, 0.0 , 1)  # x方向-0.1
                rospy.sleep(5.0)
            
            elif self.current_goal_index == 16:  # 目标点17（原19）
                rospy.loginfo("发布到达box消息")
                self.arrived_box_pub.publish(Int32(1))
                self.publish_velocity(0.0, 0.1 , 1)  # y方向0.1
                self.publish_velocity(-0.1, 0.0 , 1)  # x方向-0.1
                rospy.sleep(5.0)
            
            elif self.current_goal_index == 9:  # 目标点10（原12）前
                self.publish_velocity(0.1, 0.0 , 1)  # x方向-0.1
                self.publish_velocity(0.0, -0.1 , 1)  # y方向0.1
                rospy.sleep(0.5)
            
            elif self.current_goal_index in [1, 2, 3, 4, 10, 11, 12, 13]:  # 需要等待YOLO的目标点
                rospy.loginfo("发布到达消息")
                self.arrived_pub.publish(Int32(1))
                
                rospy.loginfo("等待YOLO检测消息...")
                self.yolo_received = False
                while not self.yolo_received and not rospy.is_shutdown():
                    rospy.sleep(0.1)
                rospy.loginfo("收到YOLO检测消息")
            
            elif self.current_goal_index in [6, 14, 15]:  # 需要立即发布下一个目标点的点
                rospy.loginfo("目标点#{self.current_goal_index+1}超时，继续下一个目标")
            
            # 准备下一个目标
            self.current_goal_index += 1
            
            # 延迟发布下一个目标
            rospy.Timer(rospy.Duration(0.5), self.delayed_publish, oneshot=True)

if __name__ == '__main__':
    try:
        node = MultiGoalPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass